'use strict';

var _createClass = require('babel-runtime/helpers/create-class')['default'];

var _classCallCheck = require('babel-runtime/helpers/class-call-check')['default'];

var _toConsumableArray = require('babel-runtime/helpers/to-consumable-array')['default'];

var _regeneratorRuntime = require('babel-runtime/regenerator')['default'];

Object.defineProperty(exports, '__esModule', {
  value: true
});

var _lodash = require('lodash');

/**
 * The base class for migrations.
 */

var Migration = (function () {
  /**
   * Creates a new Migration.
   *
   * @param configuration {object} The migration configuration.
   */

  function Migration(configuration) {
    _classCallCheck(this, Migration);

    if (!configuration) throw new Error('Configuration not specified.');

    this._client = configuration.client;
    this._index = configuration.index;
  }

  /**
   * Returns the description of the migration.
   */

  _createClass(Migration, [{
    key: 'count',

    /**
     * Returns the number of objects that can be upgraded by this migration.
     */
    value: function count() {
      return _regeneratorRuntime.async(function count$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            return context$2$0.abrupt('return', 0);

          case 1:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this);
    }

    /**
     * Performs an upgrade and returns the number of objects upgraded.
     */
  }, {
    key: 'upgrade',
    value: function upgrade() {
      return _regeneratorRuntime.async(function upgrade$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            return context$2$0.abrupt('return', 0);

          case 1:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this);
    }

    /**
     * Performs an Elasticsearch query using the scroll API and returns the hits.
     *
     * @param index - The index to search.
     * @param type - The type to search.
     * @param query - The query body.
     * @param options - Additional options for the search method; currently the
     *                  only supported one is `size`.
     * @return The search hits.
     */
  }, {
    key: 'scrollSearch',
    value: function scrollSearch(index, type, query, options) {
      var objects, opts, searchOptions, response;
      return _regeneratorRuntime.async(function scrollSearch$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            objects = [];
            opts = (0, _lodash.defaults)(options || {}, {
              size: 100
            });
            searchOptions = {
              index: index,
              type: type,
              scroll: '1m',
              size: opts.size
            };

            if (query) {
              searchOptions.body = query;
            }

            context$2$0.next = 6;
            return _regeneratorRuntime.awrap(this._client.search(searchOptions));

          case 6:
            response = context$2$0.sent;

          case 7:
            if (!true) {
              context$2$0.next = 16;
              break;
            }

            objects.push.apply(objects, _toConsumableArray(response.hits.hits));

            if (!(objects.length === response.hits.total)) {
              context$2$0.next = 11;
              break;
            }

            return context$2$0.abrupt('break', 16);

          case 11:
            context$2$0.next = 13;
            return _regeneratorRuntime.awrap(this._client.scroll({
              scroll: '1m',
              scroll_id: response._scroll_id
            }));

          case 13:
            response = context$2$0.sent;
            context$2$0.next = 7;
            break;

          case 16:
            return context$2$0.abrupt('return', objects);

          case 17:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this);
    }

    /**
     * Performs an Elasticsearch query and returns the number of hits.
     *
     * @param index - The index to search.
     * @param type - The type to search.
     * @param query - The query body.
     * @return The number of search hits.
     */
  }, {
    key: 'countHits',
    value: function countHits(index, type, query) {
      var searchOptions, response;
      return _regeneratorRuntime.async(function countHits$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            searchOptions = {
              index: index,
              type: type,
              body: query
            };
            context$2$0.next = 3;
            return _regeneratorRuntime.awrap(this._client.count(searchOptions));

          case 3:
            response = context$2$0.sent;
            return context$2$0.abrupt('return', response.count);

          case 5:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this);
    }
  }], [{
    key: 'description',
    get: function get() {
      return 'No description';
    }
  }]);

  return Migration;
})();

exports['default'] = Migration;
;
module.exports = exports['default'];
