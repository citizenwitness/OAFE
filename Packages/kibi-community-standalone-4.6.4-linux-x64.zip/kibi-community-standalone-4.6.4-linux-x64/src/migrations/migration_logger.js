/**
 * A logger for migrations.
 */
'use strict';

var _createClass = require('babel-runtime/helpers/create-class')['default'];

var _classCallCheck = require('babel-runtime/helpers/class-call-check')['default'];

Object.defineProperty(exports, '__esModule', {
  value: true
});

var MigrationLogger = (function () {

  /**
   * Creates a new MigrationLogger.
   *
   * @param {KbnServer.server} server - A server instance.
   * @param {String} name - The logger name.
   */

  function MigrationLogger(server, name) {
    _classCallCheck(this, MigrationLogger);

    this._name = name;
    this._server = server;
  }

  _createClass(MigrationLogger, [{
    key: 'error',
    value: function error(message) {
      this._server.log(['error', this._name], message);
    }
  }, {
    key: 'warning',
    value: function warning(message) {
      this._server.log(['warning', this._name], message);
    }
  }, {
    key: 'debug',
    value: function debug(message) {
      this._server.log(['debug', this._name], message);
    }
  }, {
    key: 'info',
    value: function info(message) {
      this._server.log(['info', this._name], message);
    }
  }]);

  return MigrationLogger;
})();

exports['default'] = MigrationLogger;
;
module.exports = exports['default'];
