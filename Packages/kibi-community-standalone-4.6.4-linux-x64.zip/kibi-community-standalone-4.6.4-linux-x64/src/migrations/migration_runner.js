'use strict';

var _createClass = require('babel-runtime/helpers/create-class')['default'];

var _classCallCheck = require('babel-runtime/helpers/class-call-check')['default'];

var _getIterator = require('babel-runtime/core-js/get-iterator')['default'];

var _regeneratorRuntime = require('babel-runtime/regenerator')['default'];

Object.defineProperty(exports, '__esModule', {
  value: true
});

var _lodash = require('lodash');

/**
 * A migration runner.
 */

var MigrationRunner = (function () {
  /**
   * Creates a new Migration runner.
   *
   * @param {MigrationLogger} logger A logger instance.
   * @param {KbnServer.server} server A server instance.
   */

  function MigrationRunner(server, logger) {
    _classCallCheck(this, MigrationRunner);

    this._server = server;
    this._logger = logger;
  }

  /**
   * Gets migration classes from plugins that expose the `getMigrations`
   * method and instantiates them.
   *
   * The runner passes a configuration object to the migration constructor which
   * contains the following attributes:
   *
   * - index: the name of the Kibi index.
   * - client: an instance of an Elasticsearch client configured to connect to the Kibi cluster.
   *
   * Each migration must expose the following:
   *
   * - `count`: returns the number of objects that can be upgraded.
   * - `upgrade`: runs the migration and returns the number of upgraded
   *              objects.
   *
   * Migrations are cached and executed in the order returned by each plugin;
   * the plugins are scanned in the order returned by the PluginCollection in
   * server.plugins.
   *
   * Currently it is not possible to defined dependencies between migrations
   * declared in different plugins, so be careful about modifying objects
   * shared by more than one plugin.
   */

  _createClass(MigrationRunner, [{
    key: 'getMigrations',
    value: function getMigrations() {
      var _this = this;

      if (this._migrations) {
        return this._migrations;
      }
      var migrations = [];
      (0, _lodash.each)(this._server.plugins, function (plugin) {
        if ((0, _lodash.has)(plugin, 'getMigrations')) {
          var _iteratorNormalCompletion = true;
          var _didIteratorError = false;
          var _iteratorError = undefined;

          try {
            for (var _iterator = _getIterator(plugin.getMigrations()), _step; !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true) {
              var Migration = _step.value;

              var configuration = {
                index: _this._server.config().get('kibana.index'),
                client: _this._server.plugins.elasticsearch.client,
                logger: _this._logger
              };
              var migration = new Migration(configuration);
              migrations.push(migration);
            }
          } catch (err) {
            _didIteratorError = true;
            _iteratorError = err;
          } finally {
            try {
              if (!_iteratorNormalCompletion && _iterator['return']) {
                _iterator['return']();
              }
            } finally {
              if (_didIteratorError) {
                throw _iteratorError;
              }
            }
          }
        }
      });
      this._migrations = migrations;
      return this._migrations;
    }

    /**
     * Counts objects that can be upgraded by executing the `count` method of each migration returned by the installed plugins.
     *
     * @returns The number of objects that can be upgraded.
     */
  }, {
    key: 'count',
    value: function count() {
      var count, _iteratorNormalCompletion2, _didIteratorError2, _iteratorError2, _iterator2, _step2, migration;

      return _regeneratorRuntime.async(function count$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            count = 0;
            _iteratorNormalCompletion2 = true;
            _didIteratorError2 = false;
            _iteratorError2 = undefined;
            context$2$0.prev = 4;
            _iterator2 = _getIterator(this.getMigrations());

          case 6:
            if (_iteratorNormalCompletion2 = (_step2 = _iterator2.next()).done) {
              context$2$0.next = 14;
              break;
            }

            migration = _step2.value;
            context$2$0.next = 10;
            return _regeneratorRuntime.awrap(migration.count());

          case 10:
            count += context$2$0.sent;

          case 11:
            _iteratorNormalCompletion2 = true;
            context$2$0.next = 6;
            break;

          case 14:
            context$2$0.next = 20;
            break;

          case 16:
            context$2$0.prev = 16;
            context$2$0.t0 = context$2$0['catch'](4);
            _didIteratorError2 = true;
            _iteratorError2 = context$2$0.t0;

          case 20:
            context$2$0.prev = 20;
            context$2$0.prev = 21;

            if (!_iteratorNormalCompletion2 && _iterator2['return']) {
              _iterator2['return']();
            }

          case 23:
            context$2$0.prev = 23;

            if (!_didIteratorError2) {
              context$2$0.next = 26;
              break;
            }

            throw _iteratorError2;

          case 26:
            return context$2$0.finish(23);

          case 27:
            return context$2$0.finish(20);

          case 28:
            return context$2$0.abrupt('return', count);

          case 29:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this, [[4, 16, 20, 28], [21,, 23, 27]]);
    }

    /**
     * Performs an upgrade by executing the `upgrade` method of each migration returned by the installed plugins.
     *
     * @returns The number of objects upgraded.
     */
  }, {
    key: 'upgrade',
    value: function upgrade() {
      var upgraded, _iteratorNormalCompletion3, _didIteratorError3, _iteratorError3, _iterator3, _step3, migration, count;

      return _regeneratorRuntime.async(function upgrade$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            upgraded = 0;
            _iteratorNormalCompletion3 = true;
            _didIteratorError3 = false;
            _iteratorError3 = undefined;
            context$2$0.prev = 4;
            _iterator3 = _getIterator(this.getMigrations());

          case 6:
            if (_iteratorNormalCompletion3 = (_step3 = _iterator3.next()).done) {
              context$2$0.next = 18;
              break;
            }

            migration = _step3.value;

            this._logger.info('Processing migration "' + migration.constructor.description + '"');
            context$2$0.next = 11;
            return _regeneratorRuntime.awrap(migration.upgrade());

          case 11:
            count = context$2$0.sent;

            upgraded += count;
            if (count > 0) {
              this._logger.info('Upgraded ' + count + ' objects.');
            } else {
              this._logger.info('No objects upgraded.');
            }
            this._logger.info('Processed migration "' + migration.constructor.description + '"');

          case 15:
            _iteratorNormalCompletion3 = true;
            context$2$0.next = 6;
            break;

          case 18:
            context$2$0.next = 24;
            break;

          case 20:
            context$2$0.prev = 20;
            context$2$0.t0 = context$2$0['catch'](4);
            _didIteratorError3 = true;
            _iteratorError3 = context$2$0.t0;

          case 24:
            context$2$0.prev = 24;
            context$2$0.prev = 25;

            if (!_iteratorNormalCompletion3 && _iterator3['return']) {
              _iterator3['return']();
            }

          case 27:
            context$2$0.prev = 27;

            if (!_didIteratorError3) {
              context$2$0.next = 30;
              break;
            }

            throw _iteratorError3;

          case 30:
            return context$2$0.finish(27);

          case 31:
            return context$2$0.finish(24);

          case 32:
            return context$2$0.abrupt('return', upgraded);

          case 33:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this, [[4, 20, 24, 32], [25,, 27, 31]]);
    }
  }]);

  return MigrationRunner;
})();

exports['default'] = MigrationRunner;
;
module.exports = exports['default'];
