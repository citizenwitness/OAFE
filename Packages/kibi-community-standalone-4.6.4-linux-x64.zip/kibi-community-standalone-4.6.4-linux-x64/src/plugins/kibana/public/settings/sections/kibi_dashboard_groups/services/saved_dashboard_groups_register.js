define(function (require) {
  return function savedDashboardGroupsObjectFn(savedDashboardGroups) {
    return savedDashboardGroups;
  };
});
