define(function (require) {
  return function savedDatasourceObjectFn(savedDatasources) {
    return savedDatasources;
  };
});
