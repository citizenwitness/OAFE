define(function (require) {
  return function savedQueryObjectFn(savedQueries) {
    return savedQueries;
  };
});
