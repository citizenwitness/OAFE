define(function (require) {
  return function savedTemplatesObjectFn(savedTemplates) {
    return savedTemplates;
  };
});
