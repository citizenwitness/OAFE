'use strict';

var _interopRequireDefault = require('babel-runtime/helpers/interop-require-default')['default'];

var _libCrypto_helper = require('./lib/crypto_helper');

var _libCrypto_helper2 = _interopRequireDefault(_libCrypto_helper);

/**
 * The Kibi core plugin.
 *
 * The plugin exposes the following methods to other hapi plugins:
 *
 * - getQueryEngine: returns an instance of QueryEngine.
 * - getIndexHelper: returns an instance of IndexHelper.
 */
var _ = require('lodash');
var http = require('http');
var path = require('path');
var Boom = require('boom');
var errors = require('request-promise/errors');

var util = require('../elasticsearch/lib/util');

var dbfilter = require('../elasticsearch/lib/dbfilter');
var inject = require('../elasticsearch/lib/inject');

module.exports = function (kibana) {

  var datasourcesSchema = require('./lib/datasources_schema');
  var QueryEngine = require('./lib/query_engine');
  var IndexHelper = require('./lib/index_helper');
  var queryEngine;
  var indexHelper;

  var migrations = [require('./lib/migrations/migration_1'), require('./lib/migrations/migration_2'), require('./lib/migrations/migration_3'), require('./lib/migrations/migration_4'), require('./lib/migrations/migration_5')];

  var _validateQueryDefs = function _validateQueryDefs(queryDefs) {
    if (queryDefs && queryDefs instanceof Array) {
      return true;
    }
    return false;
  };

  var _handler = function _handler(server, method, req, reply) {
    var params = req.query;
    var options = {};
    var queryDefs = [];

    if (params.options) {
      try {
        options = JSON.parse(params.options);
      } catch (e) {
        server.log(['error', 'kibi_core'], 'Could not parse options [' + params.options + '] for method [' + method + '].');
      }
    }

    if (params.queryDefs) {
      try {
        queryDefs = JSON.parse(params.queryDefs);
      } catch (e) {
        server.log(['error', 'kibi_core'], 'Could not parse queryDefs [' + params.queryDefs + '] for method [' + method + '].');
      }
    }

    if (_validateQueryDefs(queryDefs) === false) {
      return reply({
        query: '',
        error: 'queryDefs should be an Array of queryDef objects'
      });
    }

    var config = server.config();
    if (config.has('shield.cookieName')) {
      options.credentials = req.state[config.get('shield.cookieName')];
    }
    if (req.auth && req.auth.credentials && req.auth.credentials.proxyCredentials) {
      options.credentials = req.auth.credentials.proxyCredentials;
    }
    queryEngine[method](queryDefs, options).then(function (queries) {
      return reply({
        query: params,
        snippets: queries
      });
    })['catch'](function (error) {
      var err = undefined;
      if (error instanceof Error) {
        err = Boom.wrap(error, 400);
      } else {
        //When put additional data in badRequest() it's not be used. So we need to add error.message manually
        var msg = 'Failed to execute query on an external datasource' + (error.message ? ': ' + error.message : '');
        err = Boom.badRequest(msg);
      }
      return reply(err);
    });
  };

  return new kibana.Plugin({
    require: ['kibana'],

    id: 'kibi_core',

    config: function config(Joi) {
      return Joi.object({
        enabled: Joi.boolean()['default'](true),

        load_jdbc: Joi.boolean()['default'](false),

        enterprise_enabled: Joi.boolean()['default'](false),
        elasticsearch: Joi.object({
          auth_plugin: Joi.string().allow('')['default'](''),
          transport_client: Joi.object({
            username: Joi.string().allow('')['default'](''),
            password: Joi.string().allow('')['default'](''),
            ssl: Joi.object({
              ca: Joi.string().allow('')['default'](''),
              ca_password: Joi.string().allow('')['default'](''),
              ca_alias: Joi.string().allow('')['default'](''),
              key_store: Joi.string().allow('')['default'](''),
              key_store_password: Joi.string().allow('')['default'](''),
              key_store_alias: Joi.string().allow('')['default'](''),
              verify_hostname: Joi.boolean()['default'](true),
              verify_hostname_resolve: Joi.boolean()['default'](false)
            })
          })
        }),
        gremlin_server: Joi.object({
          log_conf_path: Joi.string().allow('')['default'](''),
          debug_remote: Joi.string().allow('')['default'](''),
          path: Joi.string().allow('')['default'](''),
          url: Joi.string().uri({ scheme: ['http', 'https'] })['default']('http://127.0.0.1:8080'),
          ssl: Joi.object({
            key_store: Joi.string()['default'](''),
            key_store_password: Joi.string()['default'](''),
            ca: Joi.string().allow('')['default']('')
          })
        }),

        datasource_encryption_algorithm: Joi.string()['default']('AES-GCM'),
        datasource_encryption_key: Joi.string()['default']('iSxvZRYisyUW33FreTBSyJJ34KpEquWznUPDvn+ka14='),

        datasources_schema: Joi.any()['default'](datasourcesSchema),
        datasource_cache_size: Joi.number()['default'](500),

        default_dashboard_title: Joi.string().allow('')['default']('')
      })['default']();
    },

    init: function init(server, options) {
      var _this = this;

      var config = server.config();
      var datasourceCacheSize = config.get('kibi_core.datasource_cache_size');

      var filterJoinSet = require('../elasticsearch/lib/filter_join')(server).set;
      var filterJoinSequence = require('../elasticsearch/lib/filter_join')(server).sequence;

      this.status.yellow('Initialising the query engine');
      queryEngine = new QueryEngine(server);
      queryEngine._init(datasourceCacheSize).then(function (data) {
        server.log(['info', 'kibi_core'], data);
        _this.status.green('Query engine initialized');
      })['catch'](function (err) {
        server.log(['error', 'kibi_core'], err);
        _this.status.red('Query engine initialization failed');
      });

      server.expose('getQueryEngine', function () {
        return queryEngine;
      });

      server.expose('getCryptoHelper', function () {
        return _libCrypto_helper2['default'];
      });

      indexHelper = new IndexHelper(server);
      server.expose('getIndexHelper', function () {
        return indexHelper;
      });

      // Expose the migrations
      server.expose('getMigrations', function () {
        return migrations;
      });

      server.route({
        method: 'GET',
        path: '/clearCache',
        handler: function handler(req, reply) {
          _handler(server, 'clearCache', req, reply);
        }
      });

      server.route({
        method: 'GET',
        path: '/getQueriesHtml',
        handler: function handler(req, reply) {
          _handler(server, 'getQueriesHtml', req, reply);
        }
      });

      server.route({
        method: 'GET',
        path: '/getQueriesData',
        handler: function handler(req, reply) {
          _handler(server, 'getQueriesData', req, reply);
        }
      });

      server.route({
        method: 'GET',
        path: '/getIdsFromQueries',
        handler: function handler(req, reply) {
          _handler(server, 'getIdsFromQueries', req, reply);
        }
      });

      server.route({
        method: 'POST',
        path: '/gremlin',
        handler: function handler(req, reply) {
          queryEngine._getDatasourceFromEs(req.payload.params.datasourceId).then(function (datasource) {
            var config = server.config();
            var params = JSON.parse(datasource.datasourceParams);
            params.credentials = null;
            if (config.has('shield.cookieName')) {
              var _req$state$config$get = req.state[config.get('shield.cookieName')];
              var username = _req$state$config$get.username;
              var password = _req$state$config$get.password;

              params.credentials = { username: username, password: password };
            }
            if (req.auth && req.auth.credentials && req.auth.credentials.proxyCredentials) {
              params.credentials = req.auth.credentials.proxyCredentials;
            }
            return queryEngine.gremlin(params, req.payload.params.options);
          }).then(reply)['catch'](errors.StatusCodeError, function (err) {
            reply(Boom.create(err.statusCode, err.error.message || err.message, err.error.stack));
          })['catch'](errors.RequestError, function (err) {
            if (err.error.code === 'ETIMEDOUT') {
              reply(Boom.create(408, err.message, ''));
            } else if (err.error.code === 'ECONNREFUSED') {
              reply({ error: 'Could not send request to Gremlin server, please check if it is running. Details: ' + err.message });
            } else {
              reply({ error: 'An error occurred while sending a gremlin query: ' + err.message });
            }
          });
        }
      });

      /*
       * Translate a query containing kibi-specific DSL into an Elasticsearch query
       */
      server.route({
        method: 'POST',
        path: '/translateToES',
        handler: function handler(req, reply) {
          var serverConfig = server.config();
          util.getQueriesAsPromise(req.payload.query).map(function (query) {
            // Remove the custom queries from the body
            inject.save(query);
            return query;
          }).map(function (query) {
            var credentials = serverConfig.has('shield.cookieName') ? req.state[serverConfig.get('shield.cookieName')] : null;
            if (req.auth && req.auth.credentials && req.auth.credentials.proxyCredentials) {
              credentials = req.auth.credentials.proxyCredentials;
            }
            return dbfilter(server.plugins.kibi_core.getQueryEngine(), query, credentials);
          }).map(function (query) {
            return filterJoinSet(query);
          }).map(function (query) {
            return filterJoinSequence(query);
          }).then(function (data) {
            reply({ translatedQuery: data[0] });
          })['catch'](function (err) {
            var errStr = undefined;
            if (typeof err === 'object' && err.stack) {
              errStr = err.toString();
            } else {
              errStr = JSON.stringify(err, null, ' ');
            }
            reply(Boom.wrap(new Error(errStr, 400)));
          });
        }
      });

      server.route({
        method: 'POST',
        path: '/gremlin/ping',
        handler: function handler(req, reply) {
          queryEngine.gremlinPing(req.payload.url).then(reply)['catch'](errors.StatusCodeError, function (err) {
            reply(Boom.create(err.statusCode, err.error.message || err.message, err.error.stack));
          })['catch'](errors.RequestError, function (err) {
            if (err.error.code === 'ETIMEDOUT') {
              reply(Boom.create(408, err.message, ''));
            } else if (err.error.code === 'ECONNREFUSED') {
              reply({ error: 'Could not send request to Gremlin server, please check if it is running. Details: ' + err.message });
            } else {
              reply({ error: 'An error occurred while sending a gremlin ping: ' + err.message });
            }
          });
        }
      });

      // Adding a route to serve static content for enterprise modules.
      server.route({
        method: 'GET',
        path: '/static/{param*}',
        handler: {
          directory: {
            path: path.normalize(path.join(__dirname, '../../../installedPlugins/'))
          }
        }
      });
    }

  });
};
