'use strict';

var _interopRequireDefault = require('babel-runtime/helpers/interop-require-default')['default'];

var _requirefrom = require('requirefrom');

var _requirefrom2 = _interopRequireDefault(_requirefrom);

var MigrationRunner = (0, _requirefrom2['default'])('src/migrations')('migration_runner');
var MigrationLogger = (0, _requirefrom2['default'])('src/migrations')('migration_logger');

/**
 * The migrations plugin checks if there are objects that can be upgraded.
 */
module.exports = function (kibana) {

  return new kibana.Plugin({
    require: ['elasticsearch'],
    id: 'migrations',

    init: function init(server, options) {
      var _this = this;

      this.status.yellow('Checking for out of date objects.');

      var checkMigrations = function checkMigrations() {
        var logger = new MigrationLogger(server, 'migrations');
        var runner = new MigrationRunner(server, logger);

        runner.count().then(function (count) {
          if (count > 0) {
            _this.status.red('There are ' + count + ' objects that are out of date; please run "bin/kibi upgrade" and restart the server.');
          } else {
            _this.status.green('All objects are up to date.');
          }
        })['catch'](function (err) {
          server.log(['error', 'migration'], err);
          _this.status.red('An error occurred while checking for out of date objects: ' + err);
        });
      };

      var status = server.plugins.elasticsearch.status;
      if (status && status.state === 'green') {
        checkMigrations();
      } else {
        status.on('change', function () {
          if (server.plugins.elasticsearch.status.state === 'green') {
            checkMigrations();
          }
        });
      }
    }

  });
};
