'use strict';

var _Set = require('babel-runtime/core-js/set')['default'];

var _interopRequireDefault = require('babel-runtime/helpers/interop-require-default')['default'];

Object.defineProperty(exports, '__esModule', {
  value: true
});

var _libInit_registry = require('./lib/init_registry');

var _libInit_registry2 = _interopRequireDefault(_libInit_registry);

var _libModelModel = require('./lib/model/model');

var _libModelModel2 = _interopRequireDefault(_libModelModel);

var _libModelBuiltin = require('./lib/model/builtin');

var _libModelBuiltin2 = _interopRequireDefault(_libModelBuiltin);

/**
 * Saved objects API plugin.
 *
 * This plugin provides an API to perform crud operations on saved objects.
 *
 * Might be superseded by https://github.com/elastic/kibana/issues/5480 at some point.
 *
 * The plugin exposes the following methods:
 *
 * `registerType(configuration)`: allows to register a new type with the specified configuration.
 *                                Configuration is expected to contain a `schema` attribute with
 *                                a Joi instance containing the schema of the type, a `type`
 *                                attribute containing the type name and an optional `title`
 *                                attribute containing the type title.
 * `getModel(typeName)`: returns the model instance for the specified type name.
 * `getTypes()`: returns the registered type as `{type: 'name', title: 'title'}`.
 * `registerMiddleware(middleware)`: allows to register an API middleware.
 * `getMiddlewares()`: returns the list of registered API middlewares.
 * `getServerCredentials`: returns the server credentials.
 */

exports['default'] = function (kibana) {

  var API_ROOT = '/api/saved-objects/v1';

  return new kibana.Plugin({
    name: 'saved_objects_api',
    require: ['elasticsearch', 'kibi_core'],

    init: function init(server, options) {
      var config = server.config();

      var typeRegistry = (0, _libInit_registry2['default'])(server);
      var middlewares = new _Set();

      require('./lib/routes/v1')(server, API_ROOT);

      /**
       * Format errors to have a structure similar to the one
       * returned by the Elasticsearch REST API.
       */
      server.ext('onPreResponse', function (request, reply) {
        if (request.path && request.path.indexOf(API_ROOT) !== 0) {
          return reply['continue']();
        }
        var response = request.response;
        if (response.isBoom) {
          response.output.payload = {
            error: {
              type: response.output.payload.error,
              reason: response.output.payload.message
            },
            status: response.output.statusCode
          };
        }
        return reply['continue']();
      });

      server.expose('registerType', function (configuration) {
        typeRegistry.set(configuration.type, new _libModelModel2['default'](server, configuration.type, configuration.schema, configuration.title));
      });
      server.expose('registerMiddleware', function (middleware) {
        return middlewares.add(middleware);
      });
      server.expose('getMiddlewares', function () {
        return middlewares;
      });
      server.expose('getModel', function (typeName) {
        return typeRegistry.get(typeName);
      });
      server.expose('getTypes', function () {
        return typeRegistry.list();
      });
      server.expose('getServerCredentials', function () {
        var username = config.get('elasticsearch.username');
        var password = config.get('elasticsearch.password');
        if (username && password) {
          var authHeader = new Buffer(username + ':' + password).toString('base64');
          return {
            headers: {
              authorization: 'Basic ' + authHeader
            }
          };
        }
      });
    },

    uiExports: {
      hacks: ['plugins/saved_objects_api/services/types', 'plugins/saved_objects_api/modals/service'],
      injectDefaultVars: function injectDefaultVars() {
        return {
          savedObjectsAPIBuiltin: _libModelBuiltin2['default']
        };
      }
    }

  });
};

module.exports = exports['default'];
