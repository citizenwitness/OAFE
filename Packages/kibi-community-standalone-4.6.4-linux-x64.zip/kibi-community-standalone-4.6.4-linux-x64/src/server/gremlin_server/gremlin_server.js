'use strict';

var _toArray = require('babel-runtime/helpers/to-array')['default'];

var childProcess = require('child_process');
var fs = require('fs');
var Promise = require('bluebird');
var rp = require('request-promise');
var http = require('http');
var path = require('path');
var _ = require('lodash');
var os = require('os');
var url = require('url');

function GremlinServerHandler(server) {
  this.gremlinServer = null;
  this.initialized = false;
  this.server = server;
  this.javaChecked = false;
}

function startServer(self, fulfill, reject) {
  var config = self.server.config();
  var gremlinServerPath = config.get('kibi_core.gremlin_server.path');
  var gremlinServerRemoteDebug = config.get('kibi_core.gremlin_server.debug_remote');

  if (gremlinServerPath) {
    (function () {
      // regex for ipv4 ip+port
      var re = /.*?([0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}:[0-9]*).*/;

      isJavaVersionOk(self).then(function () {
        self.server.plugins.elasticsearch.client.nodes.info({ nodeId: '_local' }).then(function (response) {
          var esTransportAddress = null;
          var esTransportAddressCollectedValues = [];
          _.each(response.nodes, function (node) {
            if (node.transport_address) {
              // transport_address can come in many different flavours
              // currently we support this ones for ipv4:
              // 127.0.0.1:9300
              // demo.example.com/127.0.0.1:9300
              // inet[/127.0.0.1:9303]
              esTransportAddressCollectedValues.push(node.transport_address);
              var matches = node.transport_address.match(re);
              if (matches.length === 2 && matches[1].indexOf(node.ip) === 0) {
                esTransportAddress = matches[1];
                return false; // to break the loop
              }
            }
          });
          if (!esTransportAddress) {
            return Promise.reject(new Error('Unable to get the transport address.\n' + 'Currently supported values are:\n' + '127.0.0.1:9300\n' + 'host.com/127.0.0.1:9300\n' + 'inet[/127.0.0.1:9303]\n' + 'While values returned by the cluster are:\n' + JSON.stringify(esTransportAddressCollectedValues, null, '')));
          }

          var esClusterName = response.cluster_name;

          if (config.get('kibi_core.gremlin_server.ssl.ca')) {
            self.ca = fs.readFileSync(config.get('kibi_core.gremlin_server.ssl.ca'));
          }

          if (path.parse(gremlinServerPath).ext !== '.jar') {
            self.server.log(['gremlin', 'error'], 'The configuration property kibi_core.gremlin_server.path does not point to a jar file');
            return Promise.reject(new Error('The configuration property kibi_core.gremlin_server.path does not point to a jar file'));
          }

          if (!path.isAbsolute(gremlinServerPath)) {
            var rootDir = path.normalize(__dirname + path.sep + '..' + path.sep + '..' + path.sep + '..' + path.sep);
            var gremlinDirtyDir = path.join(rootDir, gremlinServerPath);
            gremlinServerPath = path.resolve(path.normalize(gremlinDirtyDir));
          }

          return fs.access(gremlinServerPath, fs.F_OK, function (error) {
            if (error !== null) {
              self.server.log(['gremlin', 'error'], 'The Kibi Gremlin Server jar file was not found. Please check the configuration');
              return Promise.reject(new Error('The Kibi Gremlin Server jar file was not found. Please check the configuration'));
            }

            var _esTransportAddress$split = esTransportAddress.split(':');

            var _esTransportAddress$split2 = _toArray(_esTransportAddress$split);

            var host = _esTransportAddress$split2[0];
            var port = _esTransportAddress$split2[1];

            var rest = _esTransportAddress$split2.slice(2);

            var transportClientUsername = config.get('kibi_core.elasticsearch.transport_client.username');
            var transportClientPassword = config.get('kibi_core.elasticsearch.transport_client.password');
            var elasticAuthPlugin = config.get('kibi_core.elasticsearch.auth_plugin');
            var transportClientSSLCaKeyStore = config.get('kibi_core.elasticsearch.transport_client.ssl.ca');
            if (transportClientSSLCaKeyStore) {
              transportClientSSLCaKeyStore = path.resolve(transportClientSSLCaKeyStore);
            }
            var transportClientSSLCaKeyStorePassword = config.get('kibi_core.elasticsearch.transport_client.ssl.ca_password');
            var transportClientSSLKeyStore = config.get('kibi_core.elasticsearch.transport_client.ssl.key_store');
            if (transportClientSSLKeyStore) {
              transportClientSSLKeyStore = path.resolve(transportClientSSLKeyStore);
            }
            var transportClientSSLKeyStoreAlias = config.get('kibi_core.elasticsearch.transport_client.ssl.key_store_alias');
            var transportClientSSLCaKeyStoreAlias = config.get('kibi_core.elasticsearch.transport_client.ssl.ca_alias');
            var transportClientSSLKeyStorePassword = config.get('kibi_core.elasticsearch.transport_client.ssl.key_store_password');
            var transportClientSSLHostNameVerification = config.get('kibi_core.elasticsearch.transport_client.ssl.verify_hostname');
            var transportClientSSLHostNameVerificationResolution = config.get('kibi_core.elasticsearch.transport_client.ssl' + '.verify_hostname_resolve');

            self.url = config.get('kibi_core.gremlin_server.url');
            var serverURL = url.parse(self.url);

            var args = ['-jar', gremlinServerPath, '--elasticNodeHost=' + host, '--elasticNodePort=' + port, '--elasticClusterName=' + esClusterName, '--server.port=' + serverURL.port];
            if (serverURL.hostname !== '0.0.0.0') {
              args.push('--server.address=' + serverURL.hostname);
            }

            if (gremlinServerRemoteDebug) {
              args.unshift(gremlinServerRemoteDebug);
            }

            var logConfigPath = config.get('kibi_core.gremlin_server.log_conf_path');
            if (logConfigPath) {
              args.push('--logging.config=' + logConfigPath);
            }

            if (transportClientUsername) {
              args.push('--elasticTransportClientUserName=' + transportClientUsername);
              args.push('--elasticTransportClientPassword=' + transportClientPassword);
            }

            if (elasticAuthPlugin) {
              args.push('--elasticAuthPlugin=' + elasticAuthPlugin);
            }

            if (transportClientSSLCaKeyStore) {
              args.push('--elasticTransportClientCAKeyStore=' + transportClientSSLCaKeyStore);
            }

            if (transportClientSSLCaKeyStorePassword) {
              args.push('--elasticTransportClientCAKeyStorePassword=' + transportClientSSLCaKeyStorePassword);
            }

            if (transportClientSSLCaKeyStoreAlias) {
              args.push('--elasticTransportClientCACertAlias=' + transportClientSSLCaKeyStoreAlias);
            }

            if (transportClientSSLKeyStore) {
              args.push('--elasticTransportClientKeyStore=' + transportClientSSLKeyStore);
            }

            if (transportClientSSLKeyStoreAlias) {
              args.push('--elasticTransportClientCertAlias=' + transportClientSSLKeyStoreAlias);
            }

            if (transportClientSSLKeyStorePassword) {
              args.push('--elasticTransportClientKeyStorePassword=' + transportClientSSLKeyStorePassword);
            }

            if (transportClientSSLHostNameVerification) {
              args.push('--elasticTransportClientSSLHostNameVerification=true');
            } else {
              args.push('--elasticTransportClientSSLHostNameVerification=false');
            }

            if (transportClientSSLHostNameVerificationResolution) {
              args.push('--elasticTransportClientSSLHostNameVerificationResolution=true');
            } else {
              args.push('--elasticTransportClientSSLHostNameVerificationResolution=false');
            }

            if (config.get('kibi_core.gremlin_server.ssl.key_store')) {
              args.push('--server.ssl.enabled=true');
              args.push('--server.ssl.key-store=' + config.get('kibi_core.gremlin_server.ssl.key_store'));
              args.push('--server.ssl.key-store-password=' + config.get('kibi_core.gremlin_server.ssl.key_store_password'));
            } else if (config.get('server.ssl.key') && config.get('server.ssl.cert')) {
              var msg = 'Since you are using Elasticsearch Shield, you should configure the SSL for the gremlin server ' + 'by configuring the key store in kibi.yml\n' + 'The following properties are required:\n' + 'kibi_core.gremlin_server.ssl.key_store\n' + 'kibi_core.gremlin_server.ssl.key_store_password\n' + 'kibi_core.gremlin_server.ssl.ca (optional)';
              self.server.log(['gremlin', 'error'], msg);
              return Promise.reject(new Error(msg));
            }

            self.server.log(['gremlin', 'info'], 'Starting the Kibi gremlin server');
            self.gremlinServer = childProcess.spawn('java', args);
            self.gremlinServer.stderr.on('data', function (data) {
              return self.server.log(['gremlin', 'error'], ('' + data).trim());
            });
            self.gremlinServer.stdout.on('data', function (data) {
              return self.server.log(['gremlin', 'info'], ('' + data).trim());
            });
            self.gremlinServer.on('error', function (err) {
              return reject;
            });

            var maxCounter = 20;
            var initialTimeout = 10000;
            var timeout = 5000;
            var counter = maxCounter;

            self.ping = function (counter) {
              if (counter > 0) {
                setTimeout(function () {
                  self._ping().then(function (resp) {
                    var jsonResp = JSON.parse(resp.toString());
                    if (jsonResp.status === 'ok') {
                      self.server.log(['gremlin', 'info'], 'Kibi gremlin server running at ' + self.url);
                      self.initialized = true;
                      fulfill({ message: 'The Kibi gremlin server started successfully.' });
                    } else {
                      self.server.log(['gremlin', 'warning'], 'Waiting for the Kibi gremlin server');
                      counter--;
                      setTimeout(function () {
                        return self.ping(counter);
                      }, timeout);
                    }
                  })['catch'](function (err) {
                    if (err.error.code !== 'ECONNREFUSED') {
                      self.server.log(['gremlin', 'error'], 'Failed to ping the Kibi gremlin server: ' + err.message);
                    } else {
                      self.server.log(['gremlin', 'warning'], 'Waiting for the Kibi gremlin server');
                    }
                    counter--;
                    setTimeout(function () {
                      return self.ping(counter);
                    }, timeout);
                  });
                }, counter === maxCounter ? initialTimeout : timeout);
              } else {
                self.server.log(['gremlin', 'error'], 'The Kibi gremlin server did not start correctly');
                self.gremlinServer.kill('SIGINT');
                reject(new Error('The Kibi gremlin server did not start correctly'));
              }
            };
            self.ping(counter);
          });
        })['catch'](reject);
      });
    })();
  } else {
    self.server.log(['gremlin', 'warning'], 'The configuration property kibi_core.gremlin_server.path is empty');
    fulfill({ message: 'The Kibi gremlin server was not started.', error: true });
  }
};

function isJavaVersionOk(self) {
  return new Promise(function (fulfill, reject) {
    var spawn = require('child_process').spawn('java', ['-version']);
    spawn.on('error', function (err) {
      self.server.log(['gremlin', 'error'], err);
    });
    spawn.stderr.on('data', function (data) {
      var result = self._checkJavaVersionString(data);
      if (result) {
        if (!result.v) {
          self.server.log(['gremlin', 'error'], result.e);
        }
        fulfill(true);
      }
    });
  });
}

GremlinServerHandler.prototype._checkJavaVersionString = function (string) {
  if (!this.javaChecked) {
    var ret = {};
    var versionLine = string.toString().split(os.EOL)[0];
    //[string, major, minor, patch, update, ...]
    var matches = versionLine.match(/(\d+?)\.(\d+?)\.(\d+?)(?:_(\d+))?/);
    if (matches) {
      if (matches.length >= 2 && matches[2] === '8') {
        ret.v = true;
      } else {
        ret.v = false;
        ret.e = 'JAVA version is lower than the requested 1.8. The Kibi Gremlin Server needs JAVA 8 to run';
      }
    } else {
      ret.v = false;
      ret.e = 'JAVA not found. Please install JAVA 8 and restart Kibi';
    }
    this.javaChecked = true;
    return ret;
  } else {
    return null;
  }
};

GremlinServerHandler.prototype.start = function () {
  var self = this;

  if (self.initialized) {
    return Promise.resolve({
      message: 'GremlinServerHandler already initialized'
    });
  }

  return new Promise(function (fulfill, reject) {
    var elasticsearchStatus = self.server.plugins.elasticsearch.status;

    if (elasticsearchStatus.state === 'green') {
      startServer(self, fulfill, reject);
    }
    elasticsearchStatus.on('change', function (prev, prevmsg) {
      if (elasticsearchStatus.state === 'green') {
        if (!self.initialized) {
          startServer(self, fulfill, reject);
        } else {
          fulfill({ message: 'GremlinServerHandler already initialized' });
        }
      }
    });
  });
};

GremlinServerHandler.prototype.stop = function () {
  var self = this;

  self.initialized = false;
  return new Promise(function (fulfill, reject) {
    self.server.log(['gremlin', 'info'], 'Stopping the Kibi gremlin server');

    if (self.gremlinServer) {
      var exitCode = self.gremlinServer.kill('SIGINT');
      if (exitCode) {
        self.server.log(['gremlin', 'info'], 'The Kibi gremlin server exited successfully');
        fulfill(true);
      } else {
        self.server.log(['gremlin', 'error'], 'The Kibi gremlin server exited with non zero status: ' + exitCode);
        reject(new Error('The Kibi gremlin server exited with non zero status: ' + exitCode));
      }
    } else {
      fulfill(true);
    }
  });
};

GremlinServerHandler.prototype._ping = function () {
  var options = {
    method: 'GET',
    uri: this.url + '/ping'
  };
  if (this.ca) {
    options.ca = this.ca;
  }
  return rp(options);
};

module.exports = GremlinServerHandler;
