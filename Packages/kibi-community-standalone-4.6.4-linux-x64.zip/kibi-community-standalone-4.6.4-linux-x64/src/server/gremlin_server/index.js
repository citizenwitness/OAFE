'use strict';

var _ = require('lodash');
var Promise = require('bluebird');

module.exports = Promise.method(function (kbnServer, server, config) {
  if (config.get('plugins.initialize') && config.get('pkg.kibiEnterpriseEnabled')) {
    var _config = server.config();
    var gremlinServerPath = _config.get('kibi_core.gremlin_server');

    if (gremlinServerPath) {
      var _ret = (function () {
        var GremlinServerHandler = require('./gremlin_server');
        var gremlin = new GremlinServerHandler(server);

        var clean = function clean(code) {
          return gremlin.stop();
        };

        kbnServer.cleaningArray.push(clean);

        return {
          v: gremlin.start()
        };
      })();

      if (typeof _ret === 'object') return _ret.v;
    } else {
      return true;
    }
  } else {
    return true;
  }
});
