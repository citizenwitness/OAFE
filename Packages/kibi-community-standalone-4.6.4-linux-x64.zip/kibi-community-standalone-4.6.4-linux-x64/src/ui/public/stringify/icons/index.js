require('!!file?name=[path][name].[ext]!ui/stringify/icons/go.png');
require('!!file?name=[path][name].[ext]!ui/stringify/icons/stop.png');
require('!!file?name=[path][name].[ext]!ui/stringify/icons/de.png');
require('!!file?name=[path][name].[ext]!ui/stringify/icons/ne.png');
require('!!file?name=[path][name].[ext]!ui/stringify/icons/us.png');
require('!!file?name=[path][name].[ext]!ui/stringify/icons/ni.png');
require('!!file?name=[path][name].[ext]!ui/stringify/icons/cv.png');
