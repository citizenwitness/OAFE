$ErrorActionPreference = "Continue"

# Number of hosts to process with Kansa.ps1 at one time
$BatchSize = 1000   

# Let's make a copy of the host list
Copy-Item .\hosts.txt .\remaining.txt

While (( Get-Content .\remaining.txt).Length )
{
    $inprogress = Get-Content .\remaining.txt -First $BatchSize
    $inprogress | Set-Content -Encoding Ascii -Force .\inprogress.txt
    $remaining  = Get-Content .\remaining.txt

    if (-not(Compare-Object $inprogress $remaining)) 
    {
        # $inprogress and $remaining arrays match, so we've already 
        # processed $remaining. Clean up after ourselves.
        "Done."
        Remove-Item .\remaining.txt
        Remove-Item .\inprogress.txt
        exit
    }

    # Copy the remaining hosts to .\remaining.txt
    $remaining | Where-Object { $_ -notin $inprogress } | Set-Content -Force -Encoding Ascii .\remaining.txt
    .\Kansa.ps1 -TargetList .\inprogress.txt -Quiet
}
