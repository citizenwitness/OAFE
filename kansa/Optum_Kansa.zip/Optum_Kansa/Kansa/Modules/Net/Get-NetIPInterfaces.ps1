﻿<#
.SYNOPSIS
Get-NetIPInterfaces.ps1
Returns data from Get-NetIPInterface
.NOTES
Next line tells Kansa.ps1 how to format this script's output
OUTPUT tsv
#>
Get-NetIPInterface